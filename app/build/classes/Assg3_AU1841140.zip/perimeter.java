/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 *@author  Preyanshu Sukhadia
 * Roll No  AU1841140
 * Q3.Program to get area and perimeter of a parallelogram.
 */
import java.util.*;

class perimeter_of_parallelogram
{
    protected double length;
    protected double breath;
    protected double perimeter;

    public perimeter_of_parallelogram(double length, double breath) {
        this.length = length;
        this.breath = breath;
    }

    public double getLength() {
        return length;
    }

    public double getBreath() {
        return breath;
    }

    double calculate() {
        perimeter = 2*(length+breath);
       return perimeter; 
    }

    void show() {
        
        System.out.println("Perimeter of parallelogram is " + perimeter);
    }
    
    
}

class area_of_parallelogram extends perimeter_of_parallelogram
{
    private double area;

    public area_of_parallelogram(double length,double breath) {
        super(length,breath);
    }
    
    void doArea()
    {
        area = super.breath*super.length;
    }
    
    @Override
     void show() {
         super.show();
      
        System.out.println("Area of parallelogram is " + area);
    }
}
public class perimeter{
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        double length,breath;
        System.out.println("Enter the length of the parallelogram :");
        length = input.nextDouble();
        
        
        System.out.println("Enter the breath of the parallelogram :");
        breath = input.nextDouble();
        
        area_of_parallelogram a = new area_of_parallelogram(length,breath);
        
        a.calculate();
        a.doArea();
        a.show();
        
    }

}

/*
run:
Enter the length of the parallelogram :
10
Enter the breath of the parallelogram :
10
Perimeter of parallelogram is 40.0
Area of parallelogram is 100.0
BUILD SUCCESSFUL (total time: 4 seconds)

*/
