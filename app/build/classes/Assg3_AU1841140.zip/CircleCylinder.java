/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author  Preyanshu Sukhadia
 * Roll No  AU1841140
 * Q4. A program to get the area and volume of cylinders by overriding methods.
 */
import java.util.*;

 class circle{
     double radius = 1.0;
     String color = "red";

    circle() {
    }
    circle(double radius){
        this.radius = radius;
    }
    circle(double radius,String color){
        this.radius = radius;
        this.color = color;
    }     
    double getRadius(){
        return radius;
    }
    void setRadius(double radius){
       this.radius = radius;
    }
    String getColor(){
        return color;
    }
    void getColor(String color){
        this.color = color;
    }
    double getArea(){
       double area = Math.PI*radius*radius;
       return area;
    }
    

    @Override
    public String toString() {
        return "Circle{" + "radius= " + radius + ", color= " + color + '}';
    }
    
    
 }
 class Cylinder extends circle{
     double height = 1.0;

    public Cylinder() {
    }

    public Cylinder(double radius){
        super(radius);
    }
    
   
    public Cylinder(double radius, String color,double height) {
        super(radius, color);
        this.height = height;
    }
    Cylinder(double radius, double height){
        this.radius = radius;
        this.height = height;
    }
     double getHeight(){
         return height;
     }
     void setHeight(double height){
         this.height = height;
     }
     double getVolume(){
         double volume = Math.PI*radius*radius*height;
         return volume;
     }

    @Override
    double getArea() {
         double area = (2*Math.PI*radius*height)+(2*Math.PI*radius);
         return area;
    }
     
 }
public class CircleCylinder {
    public static void main(String[] args) {
       double radius,height;
       Scanner input = new Scanner(System.in);
       
      
       Cylinder c1 = new Cylinder();
       System.out.println("Enter radius for 2nd cylinder");
       radius = input.nextDouble();
       
       System.out.println("Enter height for 2nd cylinder");
       height = input.nextDouble();
       
       Cylinder c2 = new Cylinder(radius,height);
       System.out.println("Enter radius for 3rd cylinder");
       radius = input.nextDouble();
       
       System.out.println("Enter height for 3rd cylinder");
       height = input.nextDouble();
       
       Cylinder c3 = new Cylinder(radius,"red",height);
       c1.setRadius(4.0);
       c1.setHeight(4.0);
       
       System.out.println("Area of 1st cylinder of radius : " + c1.getRadius() + " and height : " + c1.getHeight() + " is : " + c1.getArea());
       System.out.println("Volume of 1st cylinder of radius : " + c1.getRadius() + " and height : " + c1.getHeight() + " is : " + c1.getVolume());
       System.out.println("Area of 2nd cylinder of radius : " + c2.getRadius() + " and height : " + c2.getHeight() + " is : " + c2.getArea());
       System.out.println("Volume of 2nd cylinder of radius : " + c2.getRadius() + " and height : " + c2.getHeight() + " is : " + c2.getVolume());
       System.out.println("Area of 3rd cylinder of radius : " + c3.getRadius() + " and height : " + c3.getHeight() + " and color : " + c3.getColor() + " is : " + c3.getArea());


        
    }
    
    

}

/*
run:
Enter radius for 2nd cylinder
10
Enter height for 2nd cylinder
10
Enter radius for 3rd cylinder
20
Enter height for 3rd cylinder
20
Area of 1st cylinder of radius : 4.0 and height : 4.0 is : 125.66370614359172
Volume of 1st cylinder of radius : 4.0 and height : 4.0 is : 201.06192982974676
Area of 2nd cylinder of radius : 10.0 and height : 10.0 is : 691.1503837897545
Volume of 2nd cylinder of radius : 10.0 and height : 10.0 is : 3141.5926535897934
Area of 3rd cylinder of radius : 20.0 and height : 20.0 and color : red is : 2638.9378290154264
BUILD SUCCESSFUL (total time: 7 seconds)

*/