/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 *@author  Preyanshu Sukhadia
 * Roll No  AU1841140
 * Q7.Inheritance exercise : Parent and child class example.
 */
class Parent
{
    Parent(){
        System.out.println("Parent default constructor");
    }
    
    String getMessage(){
        return "Parent message";
    }
    
}

class Child extends Parent
{   
    Child(){
        System.out.println("Child default constructor");
    }
    
    @Override
    String getMessage(){
        return "Child message";
    }
    
}

public class InheritanceExample {
    public static void main(String[] args) {
        Child a = new Child();
        String message= a.getMessage();
        System.out.println(message);
    }
}

/*
run:
Parent default constructor
Child default constructor
Child message
BUILD SUCCESSFUL (total time: 0 seconds)

*/