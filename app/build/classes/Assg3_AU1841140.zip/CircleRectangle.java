/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 *@author  Preyanshu Sukhadia
 * Roll No  AU1841140
 * Q5.A program to get the area of circle and rectangle by overriding methods.
 */
import java.util.*;
abstract class figure{
    abstract double area();
    
}

class rectangle extends figure{

    double length;
    double breadth;
    double area;
    
    public rectangle(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
    }
    
    @Override
    double area() {

    area = length*breadth;
    return area;
    } 
    
}

 class Circle extends figure{

    double radius;
    double area;

    public Circle(double radius) {
        this.radius = radius;
    }
    
    @Override
    double area() {
        
    area= Math.PI*radius*radius;
    return area;
    }
    
}
public class CircleRectangle {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        double radius,length,breadth;
        System.out.println("Enter radius of the circle:");
        radius = input.nextDouble();
                
        Circle c1 = new Circle(radius);
        
        System.out.println("Enter length of the rectangle:");
        length = input.nextDouble();
        
        System.out.println("Enter breadth of the rectangle:");
        breadth = input.nextDouble();
        
        rectangle r1 = new rectangle(length,breadth);
        
        c1.area();
        System.out.println("The area of circle of radius " + c1.radius + " is : " + c1.area);
        r1.area();
        System.out.println("The area of rectangle of length " + r1.length + " and breadth " + r1.breadth + " is : " + r1.area);
    }
}

/*
run:
Enter radius of the circle:
10
Enter length of the rectangle:
10
Enter breadth of the rectangle:
10
The area of circle of radius 10.0 is : 314.1592653589793
The area of rectangle of length 10.0 and breadth 10.0 is : 100.0
BUILD SUCCESSFUL (total time: 5 seconds)

*/