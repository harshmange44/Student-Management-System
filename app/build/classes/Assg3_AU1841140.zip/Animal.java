/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author  Preyanshu Sukhadia
 * Roll No  AU1841140
 * Q6.Extend the Animal abstract class with two child classes: Bird and Fish. 
 * Both of them has their own functionality for the move() and eat() abstract methods. 
 * For example display message “Bird moves by flying” in move() method of Bird. 
 * Also ask the user for which animal information is to be displayed.
 */
import java.util.Scanner;
abstract class animal{
    abstract void move();
    abstract void eat();
    void label(){
        System.out.println("INFORMATION DISPLAY");
    }
    
}
class bird extends animal{

    @Override
    void label(){
        System.out.println("Some information about bird is displayed below...");
    }
   
    
    @Override
    void move() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Bird moves by flying");
    }

    @Override
    void eat() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Bird eats grains and small insects ");
    }
    
}
class fish extends animal{

    @Override
    void label(){
        System.out.println("Some information about fish is displayed below...");
    }
    
    @Override
    void move() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Fish moves by swimming");
    }

    @Override
    void eat() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        System.out.println("Fish eats small aquatic plants and some small fishes");
    }
    
    
}


public class Animal {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Animal var;
        
        System.out.println("Choose any of the given animal");
        System.out.println("1.Bird");
        System.out.println("2.Fish");
        
        int choice = input.nextInt();
        
        if(choice==1){
            
            bird b1 = new bird();
            b1.label();
            b1.eat();
            b1.move();
        }
        
        else if(choice==2){
            fish f1 = new fish();
            f1.label();
            f1.move();
            f1.eat();
        } 
        
        else{
            System.out.println("No such choice available......");
        }
    }
}