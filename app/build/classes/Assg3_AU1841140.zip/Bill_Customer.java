/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 *  @author  Preyanshu Sukhadia
 * Roll No  AU1841140
 * Q2. A program to display the details of the customer along with the telephone bill.
 */

import java.util.Scanner;
   
class Detail {
    
    String name;
    String address;
    long telno;
    double rent;
    
    Detail(){
    
        this.name = name;
        this.address = address;
        this.telno = telno;
        this.rent = rent;
    
    }
    
    void get(){
    
        Scanner input = new Scanner(System.in);
        System.out.println("Enter name:");
        name = input.nextLine();
        System.out.println("Enter  Address:");
        address = input.nextLine();
        System.out.println("Enter  Tellephone number:");
        telno = input.nextLong();
        System.out.println("Enter rent:");
        rent = input.nextDouble();
        
    }
    void show(){
    
        System.out.println("Name : " + name);
        System.out.println("Address : " + address);
        System.out.println("Tellephone number : " + telno);
        System.out.println("Rent : " + rent);
 
   }
}

class Bill extends Detail{
    
    Scanner input = new Scanner(System.in);
    int n;
    double amount = 0,rentalcharge = 100;
    
    Bill(int n){

        super();
        this.n = n;
        this.amount = amount;

    }
    
   
    
    void cal(){
        
    if(n<100){
        
        amount = rentalcharge;
    }
    else if(n>100 && n<200){
    
        amount = rentalcharge + (n*2);
        
    }
    else if(n>200 && n<300){
        
        amount = rentalcharge + (n*3);
    
    }
    else{
        
        amount = rentalcharge + (n*5);
    
    }
    
    }

    void display()
    {
    
        System.out.println("Customer Bill is : " + amount);
    }

}

public class Bill_Customer{

    public static void main(String[] args) {
        
        Bill b_object = new Bill(150);
        b_object.get();
        b_object.show();
        b_object.cal();
        b_object.display();
    }

}
    


/*
run:
Enter name:
Preyanshu Sukhadia
Enter  Address:
Ghodasar Ahmedabad
Enter  Tellephone number:
123456789
Enter rent:
100
Name : Preyanshu Sukhadia
Address : Ghodasar Ahmedabad
Tellephone number : 123456789
Rent : 100.0
Customer Bill is : 400.0
BUILD SUCCESSFUL (total time: 37 seconds)

*/